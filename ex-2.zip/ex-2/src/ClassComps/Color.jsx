import { Component } from "react";

export default class Color extends Component{
    constructor(props){
        super(props);

        this.state={
            bgcolor:'white'
        };
    }

    changeColor = (e) =>{   
        this.setState({bgcolor:e.target.id});
    };
    

    render(){      
        return(
             <div>
                <h1>Choose Color:</h1>
                <div id="btns" style={{
                    backgroundColor: this.state.bgcolor,
                    height:300,
                    paddingTop:65,
                    paddingRight:5,
                    width:500       
                }}>
                  <button id="Pink" onClick={this.changeColor} style={{margin:10}}>Pink</button>
                  <button id="Green" onClick={this.changeColor} style={{margin:10}}>Green</button>
                  <button id="Blue" onClick={this.changeColor} style={{margin:10}}>Blue</button><br/><br/>
                  <button id="Yellow" onClick={this.changeColor} style={{margin:10}}>Yellow</button>
                  <button id="Orange" onClick={this.changeColor} style={{margin:10}}>Orange</button>
                  <button id="Purple" onClick={this.changeColor} style={{margin:10}}>Purple</button><br/><br/>
                  <button id="Red" onClick={this.changeColor} style={{margin:10}}>Red</button>
                  <button id="Brown" onClick={this.changeColor} style={{margin:10}}>Brown</button>
                </div>
                <br/><br/><br/><br/>
            </div>
        );
    }
}

