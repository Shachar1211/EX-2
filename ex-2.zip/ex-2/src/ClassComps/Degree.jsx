import { Component } from "react";


export default class Degree extends Component{
    constructor(props){
        super(props);

        this.state={
            firstName: this.props.firstName,
            familyName: this.props.familyName,           
            psychometricGrade: this.props.psychometricGrade,
        };
    }

    showP=(event)=>{
        let eClassName=event.target.className;
        document.getElementById(eClassName).innerHTML="Please enter your " + eClassName;
    }
    clearP=(event)=>{
        document.getElementById("canStudy").innerHTML="";
        document.getElementById("canNotStudy").innerHTML="";
        document.getElementById(event.target.className).innerHTML="";
        this.setState({[event.target.id]: event.currentTarget.value});
        console.log(firstName);
        if(event.target.id=="psychometricGrade"){
            if(!Number(event.currentTarget.value)){
                alert("Please enter a number in the psychometric Grade");
            }
            else{
                if(Number(event.currentTarget.value)>555){
                    document.getElementById("canStudy").innerHTML="You can be accepted for studies!!";
                }
                else{
                    document.getElementById("canNotStudy").innerHTML="Sorry, you must try next year...";
                }
            }
        }
    }

    render(){        
        return(           
             <div style={{border:"2px solid black"}}>
                <form>
                <h2>Check if you can be accepted for studies:</h2>
                <p id="first Name" style={{color:"red"}}></p>
                First Name: <input type="text" id="firstName" className="first Name" placeholder={this.state.firstName} onBlur={this.clearP} onFocus={this.showP} /><br/><br/>
                <p id="family Name" style={{color:"red"}}></p>
                Family Name: <input type="text" id="familyName" className="family Name" placeholder={this.state.familyName} onBlur={this.clearP} onFocus={this.showP} /><br/><br/>

                <p id="psychometric Grade" style={{color:"red"}}></p>
                Psychometric Name: <input type="text" id="psychometricGrade" className="psychometric Grade" placeholder={this.state.psychometricName} onBlur={this.clearP} onFocus={this.showP} /><br/><br/>
                <p id="canStudy" style={{color:"green",fontWeight:"bold"}}></p>
                <p id="canNotStudy" style={{color:"black",fontWeight:"bold"}}></p>
                </form>   
            </div>
            
        );
    }
}