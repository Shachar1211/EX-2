import { Component } from "react";

export default class TTable extends Component{
    constructor(props){
        super(props);

        this.state={
            width:'100%'
        };
    }

    changeToSmallSize=() =>{
        this.setState({width:'50%'});
        console.log(this.state.width);
    }
    changeToBigSize=() =>{
        this.setState({width:'100%'});
        console.log(this.state.width);
    }

    render(){      
        return(
             <div>
                <br/><br/><br/><br/>
                <h2>Click on the table to see what will happen</h2>
                <table style={{border:"2px solid black",borderCollapse: "collapse",width:this.state.width}} onClick={this.changeToSmallSize} onDoubleClick={this.changeToBigSize}>
                    <tr>
                        <td style={{border:"2px solid black"}}>1</td>
                        <td style={{border:"2px solid black"}}>4</td>
                    </tr>
                    <tr>
                        <td style={{border:"2px solid black"}}>2</td>
                        <td style={{border:"2px solid black"}}>5</td>
                    </tr>
                    <tr>
                        <td style={{border:"2px solid black"}}>3</td>
                        <td style={{border:"2px solid black"}}>6</td>
                    </tr>
                </table>
            </div>
        );
    }
}