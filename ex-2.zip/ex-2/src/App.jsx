import './App.css';
import { useState } from 'react';
import reactLogo from './assets/react.svg';
import viteLogo from '/vite.svg';
import Color from './ClassComps/Color';
import Degree from './ClassComps/Degree';
import TTable from './ClassComps/TTable';

function App() {
  return (
    <>
    <div>
        <Color/>
        <Degree/>
        <TTable/>
    </div>
        
    </>
  )
}

export default App;
